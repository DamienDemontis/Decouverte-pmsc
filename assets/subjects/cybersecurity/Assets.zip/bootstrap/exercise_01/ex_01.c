#include <stdio.h>

void vulnerable_function(char *user_input) {
    char password[18] = "3P1-F0RM4T_STR1NG";

    printf(user_input, password);
}

int main(int argc, char *argv[]) {
    if (argc < 2) {
        printf("Usage: %s <input>\n", argv[0]);
        return 1;
    }
    vulnerable_function(argv[1]);
    return 0;
}